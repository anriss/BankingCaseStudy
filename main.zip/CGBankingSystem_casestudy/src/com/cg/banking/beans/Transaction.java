package com.cg.banking.beans;

public class Transaction {
		private int transactionID;
		private float amount;
		private String transactionType;
		public Transaction() {}
		public Transaction(float amount, String transactionType) {
			super();
			this.amount = amount;
			this.transactionType = transactionType;
		}
		public Transaction(int transactionID, float amount, String transactionType) {
			super();
			this.transactionID = transactionID;
			this.amount = amount;
			this.transactionType = transactionType;
		}
		public int getTransactionID() {
			return transactionID;
		}
		@Override
		public String toString() {
			return "Transaction [transactionID=" + transactionID + ", amount=" + amount + ", transactionType="
					+ transactionType + "]";
		}
		public void setTransactionID(int l) {
			this.transactionID = l;
		}
		public float getAmount() {
			return amount;
		}
		public void setAmount(float amount) {
			this.amount = amount;
		}
		public String getTransactionType() {
			return transactionType;
		}
		public void setTransactionType(String transactionType) {
			this.transactionType = transactionType;
		}
}
