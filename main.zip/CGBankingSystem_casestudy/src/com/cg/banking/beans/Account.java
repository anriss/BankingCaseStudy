package com.cg.banking.beans;

import java.util.HashMap;
import java.util.List;

public class Account {
	private long accountNo;
	private int pinNumber;
	private String accoutType,accountStatus;
	private float accountbalance;
	private HashMap<Integer,Transaction>transactions = new HashMap<>();
	
	public Account(String accoutType, float accountbalance) {
		super();
		this.accoutType = accoutType;
		this.accountbalance = accountbalance;
	}
	public Account(int pinNumber, String accoutType, String accountStatus, float accountbalance) {
		super();
		this.pinNumber = pinNumber;
		this.accoutType = accoutType;
		this.accountStatus = accountStatus;
		this.accountbalance = accountbalance;
	}
	public Account(int pinNumber, String accoutType, String accountStatus, float accountbalance,
			HashMap<Integer,Transaction> transactions) {
		super();
		this.pinNumber = pinNumber;
		this.accoutType = accoutType;
		this.accountStatus = accountStatus;
		this.accountbalance = accountbalance;
		this.transactions = transactions;
	}
	public Account(long accountNo, int pinNumber, String accoutType, String accountStatus, float accountbalance,
			HashMap<Integer,Transaction> transactions) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.accoutType = accoutType;
		this.accountStatus = accountStatus;
		this.accountbalance = accountbalance;
		this.transactions = transactions;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public String getAccoutType() {
		return accoutType;
	}
	public void setAccoutType(String accoutType) {
		this.accoutType = accoutType;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public float getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(float accountbalance) {
		this.accountbalance = accountbalance;
	}
	public HashMap<Integer,Transaction>  getTransactions() {
		return transactions;
	}
	public void setTransactions(HashMap<Integer,Transaction> transactions) {
		this.transactions = transactions;
	}
	
	
}
