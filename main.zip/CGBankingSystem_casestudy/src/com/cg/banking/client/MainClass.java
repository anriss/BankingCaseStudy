package com.cg.banking.client;
import java.util.List;
import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberExcpetion;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	static Scanner sc=new Scanner(System.in);
	static BankingServices services=new BankingServicesImpl();
	Account ac;
	
	public static void openAcc() {
		System.out.println("Choose Account Type( 1 for Current 2 for Savings ) : ");
		int ch = sc.nextInt();
		String type = "";
		switch(ch) {
		case 1:
			type="Current";
			break;
		case 2:
			type="Savings";
			break;
		}
		String accAndPin=services.openAccount(type, 0.0f);
		System.out.println(accAndPin);
	}
	
	public static void withAmt() throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberExcpetion, BankingServicesDownException, AccountBlockedException{
		System.out.println("Enter Account Number : ");
		long accountNo = sc.nextLong();
		System.out.println("Enter Pin Number : ");
		int pinNumber = sc.nextInt();
		if(services.checkPinforWithdraw(accountNo, pinNumber)!=true) {
			throw new AccountBlockedException();
		}
		System.out.println("Enter Amount to withdraw : ");
		float amount = sc.nextFloat();
		float accountBalance =services.withdrawAmount(accountNo,amount,pinNumber);
		System.out.println(accountBalance);
	}
	
	public static void depAmt() throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		System.out.println("Enter Account Number : ");
		long accountNo = sc.nextLong();
		System.out.println("Enter Amount : ");
		float amount = sc.nextFloat();
		
		float newAm = services.depositAmount(accountNo, amount);
		System.out.println("Balance after Deposit : "+newAm );
	}

	public static void updAcc() {
		
	}
	
	public static void getTrans() {
		TransactionDAO transactionDAO = new TransactionDAOImpl();
	
		System.out.println("Enter Account Number : ");
		long accountNo = sc.nextLong();
		
		List<Transaction> transactions = transactionDAO.findAll(accountNo);
		
		System.out.println(transactions.toString());
		
	}
	
	public static void fundTransfer() throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberExcpetion, BankingServicesDownException, AccountBlockedException {
		System.out.println("Account From : ");
		long accFrom = sc.nextLong();
		System.out.println("Account To : ");
		long accTo = sc.nextLong();
		System.out.println("Amount Transfer : ");
		float transferAmount = sc.nextFloat();
		System.out.println("Pin Number : ");
		int pinNumber = sc.nextInt();
		if(services.checkPin(accFrom, pinNumber)!=true) {
			throw new AccountBlockedException();
		}
			
		boolean res = services.fundTransfer(accTo, accFrom, transferAmount, pinNumber);
		if(res)System.out.println("Transfer Succesful");
		else System.out.println("Transfer Failed");
	}
	
	public static void main(String[] args) throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberExcpetion, BankingServicesDownException, AccountBlockedException  {
		char ch = 'y';
		while(ch=='y') {
			System.out.println("--------------------------------------------------------------------------------");
			System.out.println("\nEnter Choice of service : ");
			System.out.println("\tPress 1 for open account : ");
			System.out.println("\tPress 2 for withdraw : ");
			System.out.println("\tPress 3 for Deposit : ");
			System.out.println("\tPress 4 for update account:  ");
			System.out.println("\tPress 5 for transactions : ");
			System.out.println("\tPress 6 for fund transfer : ");
			int uCh = sc.nextInt();
			switch(uCh) {
			case 1: openAcc(); break;
			case 2: withAmt(); break;
			case 3: depAmt();  break;
			case 4: updAcc(); break;
			case 5: getTrans();break;
			case 6: fundTransfer();break;
			default: 
				System.out.println("\nPlease Enter correct choice to continue press 0 ");
				ch=sc.next().charAt(0);
			}
		}
	}
}
