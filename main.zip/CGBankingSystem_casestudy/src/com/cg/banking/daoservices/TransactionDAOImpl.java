package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO {
	@Override
	public Transaction save(long accountNo, Transaction transaction) {
		transaction.setTransactionID(BankingDBUtil.getTRANSACTION_ID());
		BankingDBUtil.accounts.get(accountNo).getTransactions().put(transaction.getTransactionID(), transaction);
		return transaction;
	}
	@Override
	public Transaction findOne(long accountNo, int transactionId) {
		return BankingDBUtil.accounts.get(accountNo).getTransactions().get(transactionId);
	}
	@Override
	public List<Transaction> findAll(long accountNo) {
		return new ArrayList<Transaction>(BankingDBUtil.accounts.get(accountNo).getTransactions().values());
	}
}
