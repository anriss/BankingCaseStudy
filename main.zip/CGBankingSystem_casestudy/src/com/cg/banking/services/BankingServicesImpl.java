package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.client.MainClass;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberExcpetion;
import com.cg.banking.util.BankingDBUtil;

public class BankingServicesImpl implements BankingServices {
	int count=0;
	private AccountDAO accountDao=new AccountDaoImpl();
	private TransactionDAO transactionDAO = new TransactionDAOImpl();
	
	@Override
	public String openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {


		//Transaction transactions=new Transaction(amount, transactionType);
		//Account account=new Account(pinNumber, accoutType, accountStatus, accountbalance, transactions);
		Account account=new Account(accountType, initBalance);
		account=accountDao.save(account);

		account.setPinNumber(BankingDBUtil.getACCOUNT_PIN());
		String accDet = "Your Account Number Is " + account.getAccountNo() + " And Pin To This Account Is : " + account.getPinNumber();
		return accDet;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account = getAccountDetails(accountNo);

		if(account == null) {
			throw new AccountNotFoundException("Please Enter valid Account Number ");
		}
		account.setAccountbalance(account.getAccountbalance()+amount);
		Transaction transaction = new Transaction(amount, "Credited");
		transactionDAO.save(accountNo, transaction);
		return account.getAccountbalance();
	}	

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberExcpetion, BankingServicesDownException, AccountBlockedException {
		int count=0;
		Account account = getAccountDetails(accountNo);
		if(getAccountDetails(accountNo)==null)
		{
			throw new AccountNotFoundException("Please Enter valid Account Number "+ accountNo);
		}

		else if(account.getPinNumber() != pinNumber) {
			count++;
			while(count<3)
			{
				throw new InvalidPinNumberExcpetion("Incorrect Pin");
			}
		}

		else if((account.getAccountbalance()-amount) < 0) {
			throw new InsufficientAmountException("Insufficient Balance ( You can withdraw amount upto:)"+(account.getAccountbalance()));
		}
		else
			account.setAccountbalance(account.getAccountbalance()-amount);
		Transaction transaction = new Transaction(amount, "Debited");
		transactionDAO.save(accountNo, transaction);
		return account.getAccountbalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberExcpetion,
			BankingServicesDownException, AccountBlockedException {
		Account sAccount = getAccountDetails(accountNoFrom);
		Account rAccount = getAccountDetails(accountNoTo);
		if(getAccountDetails(accountNoTo)==null || getAccountDetails(accountNoFrom)==null) {
			throw new AccountNotFoundException();
		}
		else if(sAccount.getPinNumber()!=pinNumber) {
			throw new InvalidPinNumberExcpetion();
		}
		else {
			if(sAccount.getAccountbalance()-transferAmount<0)
				throw new InsufficientAmountException();
			sAccount.setAccountbalance(sAccount.getAccountbalance()-transferAmount);
			rAccount.setAccountbalance(rAccount.getAccountbalance()+transferAmount);
			Transaction transaction1 = new Transaction(transferAmount, "Debited");
			transactionDAO.save(accountNoFrom, transaction1);

			Transaction transaction2 = new Transaction(transferAmount, "Credited");
			transactionDAO.save(accountNoTo, transaction2);
		}
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDao.findOne(accountNo);
		return account;
	}

	@Override
	public List<Account> getAllAcountDetails() throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getAcountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkPin(long accountNo, int pinNumber) throws InvalidPinNumberExcpetion, InsufficientAmountException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		Account account = getAccountDetails(accountNo);

		while(count<2)
		{
			if(pinNumber!=account.getPinNumber()) {
				System.out.println("Invalid Pin please try again");
				++count;
				MainClass.fundTransfer();
			}

			else
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean checkPinforWithdraw(long accountNo, int pinNumber) throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberExcpetion, BankingServicesDownException, AccountBlockedException {
		Account account = getAccountDetails(accountNo);

		while(count<2)
		{
			if(pinNumber!=account.getPinNumber()) {
				System.out.println("Invalid Pin please try again");
				++count;
				MainClass.withAmt();
			}

			else
			{
				return true;
			}
		}
		return false;
	}

		// TODO Auto-generated method stub
		
	}

