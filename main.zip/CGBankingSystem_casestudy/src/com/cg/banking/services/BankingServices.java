package com.cg.banking.services;

import javax.activity.InvalidActivityException;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberExcpetion;
import java.util.List;

public interface BankingServices {

	boolean checkPin(long accountNo, int pinNumber)
			throws InvalidPinNumberExcpetion, AccountBlockedException;

	String openAccount(String accountType,float initBalance)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;

	float depositAmount(long accountNo,float amount)
			throws AccountNotFoundException,BankingServicesDownException,AccountBlockedException;

	float withdrawAmount(long accountNo,float amount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberExcpetion,
			BankingServicesDownException,AccountBlockedException;

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberExcpetion,
			BankingServicesDownException,AccountBlockedException;

	Account getAccountDetails(long accountno)
			throws AccountNotFoundException,BankingServicesDownException;

	List<Account>getAllAcountDetails()
			throws BankingServicesDownException;

	List<Transaction>getAcountAllTransaction(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException;

	public String accountStatus(long accountNo)
			throws BankingServicesDownException,AccountNotFoundException,AccountBlockedException;

	boolean checkPinforWithdraw(long accountNo, int pinNumber) throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberExcpetion, BankingServicesDownException, AccountBlockedException;

}
