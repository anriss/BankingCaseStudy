package com.cg.banking.util;

import java.util.HashMap;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public class BankingDBUtil {
	public static HashMap<Long, Account> accounts=new HashMap<>();
	
	private static int TRANSACTION_ID = 123;
	
	private static long  ACCOUNT_NUMBER=4512;
	
	
	public static int getACCOUNT_PIN() {
		int pinNum=(int)(Math.random()*9999+1000);
		return pinNum;
	}
	
	public static long getACCOUNT_NUMBER() {
		return ++ACCOUNT_NUMBER;
	}
	
	public static int getTRANSACTION_ID() {
		return ++TRANSACTION_ID;
	}
	
	
}
